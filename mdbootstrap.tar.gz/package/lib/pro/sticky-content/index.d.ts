import { MdbStickyDirective } from './sticky-content.directive';
import { StickyContentModule } from './sticky-content.module';
export { MdbStickyDirective, StickyContentModule };
