export { ImageModalComponent } from './image-popup';
export { LightBoxModule } from './light-box.module';
