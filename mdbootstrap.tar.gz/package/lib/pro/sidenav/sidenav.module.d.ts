export declare class SidenavModule {
}
