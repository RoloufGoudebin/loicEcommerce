export declare class DatepickerModule {
}
