export interface IMyDateFormat {
    value: string;
    format: string;
}
