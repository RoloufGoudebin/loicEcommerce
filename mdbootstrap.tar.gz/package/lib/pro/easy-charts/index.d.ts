export { SimpleChartComponent } from './chart-simple.component';
export { EasyPieChartComponent } from './chart-smallpie.component';
export { ChartSimpleModule } from './chart-simple.module';
