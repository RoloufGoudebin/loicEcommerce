import { ElementRef, OnInit, OnChanges, SimpleChanges, Renderer2 } from '@angular/core';
export declare class EasyPieChartComponent implements OnInit, OnChanges {
    el: ElementRef;
    private _r;
    percent: any;
    options: any;
    pieChart: any;
    isBrowser: any;
    constructor(el: ElementRef, platformId: string, _r: Renderer2);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
}
