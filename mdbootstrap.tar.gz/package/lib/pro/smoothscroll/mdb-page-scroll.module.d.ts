/**
* Created by sebastianfuss on 03.09.16.
*/
import { ModuleWithProviders } from '@angular/core';
export declare class SmoothscrollModule {
    static forRoot(): ModuleWithProviders;
}
