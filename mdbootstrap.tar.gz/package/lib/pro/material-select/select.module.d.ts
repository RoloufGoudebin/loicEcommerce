export { IOption } from './option-interface';
export { SELECT_VALUE_ACCESSOR, SelectComponent } from './select.component';
export declare class SelectModule {
}
