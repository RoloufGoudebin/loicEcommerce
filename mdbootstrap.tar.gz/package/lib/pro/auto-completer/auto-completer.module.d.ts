export declare class AutoCompleterModule {
}
