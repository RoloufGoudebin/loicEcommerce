import { MdbOptionComponent } from '../components/mdb-option.component';
export interface ISelectedOption {
    text: string;
    element: MdbOptionComponent;
}
