import { ModuleWithProviders } from '@angular/core';
export declare class TabsModule {
    static forRoot(): ModuleWithProviders;
}
