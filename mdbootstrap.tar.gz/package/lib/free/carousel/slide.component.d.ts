import { ElementRef } from '@angular/core';
export declare class SlideComponent {
    /** Is current slide active */
    active: boolean;
    animated: boolean;
    directionNext: boolean;
    directionLeft: boolean;
    directionPrev: boolean;
    directionRight: boolean;
    /** Wraps element by appropriate CSS classes */
    el: ElementRef | any;
    constructor(el: ElementRef);
}
