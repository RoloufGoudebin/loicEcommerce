export declare class NavbarModule {
}
