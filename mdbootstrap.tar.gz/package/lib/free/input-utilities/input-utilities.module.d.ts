export declare class InputUtilitiesModule {
}
