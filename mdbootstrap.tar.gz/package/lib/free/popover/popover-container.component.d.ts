import { OnInit } from '@angular/core';
import { PopoverConfig } from './popover.config';
export declare class PopoverContainerComponent implements OnInit {
    placement: string;
    title: string;
    containerClass: string;
    bodyClass: string;
    headerClass: string;
    show: string;
    role: string;
    class: any;
    readonly isBs3: boolean;
    constructor(config: PopoverConfig);
    ngOnInit(): void;
}
