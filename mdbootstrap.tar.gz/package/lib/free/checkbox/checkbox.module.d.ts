export { CHECKBOX_VALUE_ACCESSOR, CheckboxComponent } from './checkbox.component';
export declare class CheckboxModule {
}
