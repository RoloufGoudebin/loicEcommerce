import { ElementRef, OnInit, Renderer2 } from '@angular/core';
export declare class MdbCardFooterComponent implements OnInit {
    private _el;
    private _r;
    constructor(_el: ElementRef, _r: Renderer2);
    ngOnInit(): void;
}
