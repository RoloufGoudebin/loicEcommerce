import { ModuleWithProviders } from '@angular/core';
export declare class CollapseModule {
    static forRoot(): ModuleWithProviders;
}
