/**
 * Helper used to know if the given modifier is enabled.
 */
export declare function isModifierEnabled(options: any, modifierName: string): any;
