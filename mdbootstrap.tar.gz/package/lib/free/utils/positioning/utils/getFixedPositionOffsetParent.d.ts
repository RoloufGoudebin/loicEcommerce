/**
 * Finds the first parent of an element that has a transformed property defined
 */
export declare function getFixedPositionOffsetParent(element: any): any;
