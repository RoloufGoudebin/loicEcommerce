export declare function getScrollParent(element: any): any;
