/**
 * Get the outer sizes of the given element (offset size + margins)
 */
export declare function getOuterSizes(element: any): {
    width: number;
    height: number;
};
