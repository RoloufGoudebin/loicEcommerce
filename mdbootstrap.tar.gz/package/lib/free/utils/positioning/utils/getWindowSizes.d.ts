export declare function getWindowSizes(document: any): {
    height: number;
    width: number;
};
