import { Offsets } from '../models/index';
export declare function getTargetOffsets(target: HTMLElement, hostOffsets: any, position: string): Offsets;
