import { Data } from '../models/index';
export declare function flip(data: Data): Data;
