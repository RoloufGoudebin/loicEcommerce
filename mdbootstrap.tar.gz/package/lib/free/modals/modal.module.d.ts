import { ModuleWithProviders } from '@angular/core';
export declare class ModalModule {
    static forRoot(): ModuleWithProviders;
}
